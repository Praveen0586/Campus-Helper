// global.dart
library myapp_globals;

import 'package:file_picker/file_picker.dart';

String uploadedImageUrl = "";
FilePickerResult? result_stored;
FilePickerResult? result_stored2;
