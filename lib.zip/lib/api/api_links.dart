class APIinks {
  static String base = "https://hackathon-server-18ab.onrender.com";

  static String askchatgpt =
      "https://hackathon-server-18ab.onrender.com/chatbot/ask";
}
